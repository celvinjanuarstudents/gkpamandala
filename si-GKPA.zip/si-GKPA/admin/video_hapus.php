<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id']; // Perbaikan: menggunakan kunci 'id' dari variabel $_GET

    $qry = mysqli_query($konek, "SELECT * FROM tbl_folio WHERE kode='$id'");
    $data = mysqli_fetch_array($qry);

    // Hapus gambar
    $lokasi = $data['gambar'];
    $hapus_gambar = "../img/folio/$lokasi";
    unlink($hapus_gambar);

    // Hapus data dari tabel
    $qry_delete = mysqli_query($konek, "DELETE FROM tbl_folio WHERE kode='$id'");

    if ($qry_delete) {
        header('location: folio_tampil.php');
    } else {
        echo "Gagal menghapus data. Error: " . mysqli_error($konek);
    }
}
?>

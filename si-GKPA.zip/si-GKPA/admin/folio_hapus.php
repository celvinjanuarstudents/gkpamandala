<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data dari tabel berdasarkan ID
    $qry = mysqli_query($konek, "SELECT * FROM tbl_folio WHERE kode='$id'");

    // Periksa apakah query berhasil dijalankan
    if ($qry) {
        // Periksa apakah ada data yang ditemukan
        if (mysqli_num_rows($qry) > 0) {
            $data = mysqli_fetch_array($qry);

            // Hapus gambar
            $lokasi = $data['gambar'];
            $hapus_gambar = "../img/folio/$lokasi";
            unlink($hapus_gambar);

            // Hapus data dari tabel
            $qry_delete = mysqli_query($konek, "DELETE FROM tbl_folio WHERE kode='$id'");

            if ($qry_delete) {
                header('location: folio_tampil.php');
            } else {
                echo "Gagal menghapus data. Error: " . mysqli_error($konek);
            }
        } else {
            echo "Data tidak ditemukan.";
        }
    } else {
        echo "Gagal menjalankan query. Error: " . mysqli_error($konek);
    }
}
?>

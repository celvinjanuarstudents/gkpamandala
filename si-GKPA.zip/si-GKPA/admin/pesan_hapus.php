<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($konek, $_GET['id']); // Melakukan sanitasi untuk mencegah SQL injection

    // Menghapus data dari tabel
    $qry_delete = mysqli_query($konek, "DELETE FROM tbl_pesan WHERE kode='$id'");

    if ($qry_delete) {
        header('location: tampil_pesan_read.php');
    } else {
        echo "Gagal menghapus data. Error: " . mysqli_error($konek);
    }
}
?>

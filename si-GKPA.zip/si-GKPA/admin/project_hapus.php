<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Menghapus data dari tabel
    $qry_delete = mysqli_query($konek, "DELETE FROM tbl_file WHERE kode='$id'");

    // Memeriksa apakah penghapusan berhasil
    if ($qry_delete) {
        // Mengambil lokasi data_file sebelum dihapus
        $qry_select = mysqli_query($konek, "SELECT data_file FROM tbl_file WHERE kode='$id'");
        
        // Memeriksa apakah pengambilan data berhasil
        if ($qry_select) {
            $data = mysqli_fetch_array($qry_select);
            
            // Hapus file fisik dari lokasi
            $lokasi = $data['data_file'];
            $hapus_gambar = "project/$lokasi";
            if (file_exists($hapus_gambar)) {
                unlink($hapus_gambar);
            }

            header('location: project_tampil.php');
        } else {
            echo "Gagal mengambil data sebelum dihapus. Error: " . mysqli_error($konek);
        }
    } else {
        echo "Gagal menghapus data. Error: " . mysqli_error($konek);
    }
}
?>

# Sistem Informasi Gereja Lengkap dengan source code dan database


# WARNING

- Aplikasi ini dilarang menjadikan konten anda di Youtube atau menjual secara  Komersial baik diperusahaan maupun Instansi Pemerintah.
- Aplikasi ini tidak untuk di perjualbelikan kembali ya,
- Coding ini kurang rapi atau kurang mantaplah, karena ini hanya sebagai bahan-bahan belajar saya dulu waktu D3 Komputer Tahun 2018.  
- Jika anda masih maksa untuk perjualbelikan  saya sendiri tidak bertunggung jawab karna aplikasi ini hanya untuk bahan edukasi atau referensi  


# Cara Menggunakan

- Install Xampp minimal versi php 5 keatas
- Lalu Import database yang ada di folder datababase
- Lalu suikan nama nya di file koneksi.php dan cari 
  atau di baris (6) dan susikan nama datatabase	$database= 'NAMA DATABASE';
- lalu pindahkan filenya di htdocs
- lalu buka browser Google Chrome atau mozila anda ketik localhost/folderanda

# Username dan Password

- username : admin
- password : admin
 
creation : Delisman Hulu

# Download Aplikasi Lainnya
https://layanancoding.com/daftar-aplikasi
